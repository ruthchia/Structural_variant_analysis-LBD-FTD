####Shiny app to visualize SVs

#Set working directory where files are/put files to your working directory
#setwd("~/Documents/LBD_FTD_project_2021/NIH_LBD_FTD_SV_shinyapp")
#Load libraries
library(tidyverse)
library(Gviz)
library(shiny)
library(shinyWidgets)
library(datamods)
library(biomaRt)
library(shinythemes)
library(shinysky)


#Import files
##50 NDD genes
LBD <- read.delim("LBD_1percFDR_all_info_unfiltered_with_CADDSV_genehancer_shinyapp.txt", stringsAsFactors = FALSE)
FTD <- read.delim("FTD_1percFDR_all_info_unfiltered_with_CADDSV_genehancer_shinyapp.txt", stringsAsFactors = FALSE)

##Make chr ordered factor, the sort dfs by factor order
LBD$CHROM <- factor(LBD$CHROM, ordered = TRUE, levels = c(seq(1,22),"X"))
FTD$CHROM <- factor(FTD$CHROM, ordered = TRUE, levels = c(seq(1,22),"X"))

LBD <- arrange(LBD, CHROM)
FTD <- arrange(FTD, CHROM)
##High-quality SVs whole genome
LBD_gw <- read.delim("LBD_high_quality_subset_clean_GQ300missing_all_chr.txt")
FTD_gw <- read.delim("FTD_high_quality_subset_clean_GQ300missing_all_chr.txt")

LBD_cases <- read.csv("LBD_cases_shinyapp.txt", sep="")
LBD_controls <- read.csv("LBD_controls_shinyapp.txt", sep="")
FTD_cases <- read.csv("FTD_cases_shinyapp.txt", sep="")
FTD_controls <- read.csv("FTD_controls_shinyapp.txt", sep="")
##Make chrom ordered facror and sort by it so chr are ordered in shiny app
LBD_gw$CHROM <- factor(LBD_gw$CHROM, ordered = TRUE, levels = c(paste0(rep("chr",22),seq(1,22)),"chrX"))
FTD_gw$CHROM <- factor(FTD_gw$CHROM, ordered = TRUE, levels = c(paste0(rep("chr",22),seq(1,22)),"chrX"))

LBD_gw <- arrange(LBD_gw, CHROM)
FTD_gw <- arrange(FTD_gw, CHROM)


##Gene info file
gene_info <- read.csv("gene_start_stop_name.txt", sep="")

#Initialize biomart track
bm <- useEnsembl(biomart = "genes")
bm <- useDataset(dataset = "hsapiens_gene_ensembl", mart = bm)

#Define user interface
ui <- navbarPage("LBD and FTD/ALS structural variants", theme = shinytheme("lumen"),
                 tabPanel("Neurodegenerative gene region visualisation", icon = icon(name = "image", lib = "font-awesome"),
                          sidebarLayout(
                            sidebarPanel(
                              width = 3,
                              radioButtons(inputId = "pheno2", label = "Phenotype", choiceValues = c("LBD", "FTD"), choiceNames = c("LBD", "FTD/ALS"), inline = TRUE),
                              pickerInput(inputId = "gene2", label = "Gene", choices = unique(sort(LBD$GENE)), multiple = FALSE),
                              textOutput(outputId = "SV_info2"),
                              imageOutput(outputId = "color_legend", width = "100%")
                            ),
                            mainPanel(
                              imageOutput(outputId =  "img2")
                            )
                          )
                 ),
                 tabPanel("Neurodegenerative gene data frame", icon = icon(name = "table", lib = "font-awesome"),
                          sidebarLayout(
                            sidebarPanel(
                              width = 3,
                              shiny::tags$a(href="https://github.com/ruthchia/Structural_variant_analysis-LBD-FTD/tree/main/Structural_variant_files", 
                                     "Download the data frames from here"),
                              radioButtons(inputId = "dataset", label = "Phenotype", choiceValues = c("LBD", "FTD"), choiceNames = c("LBD", "FTD/ALS")),
                              filter_data_ui("filtering"),
                            ),
                            mainPanel(
                              DT::dataTableOutput(outputId = "table")
                            )
                          )
                 ),
                 tabPanel("Genome-wide visualisation", icon = icon(name = "images", lib = "font-awesome"),
                          sidebarLayout(
                            sidebarPanel(
                              width=3,
                              shiny::tags$a(href="https://github.com/ruthchia/Structural_variant_analysis-LBD-FTD/tree/main/BigBed_files", 
                                     "Want to visualize structural variants with regulatory regions, gnomAD variants and more? Get BigBed files for Ensembl/UCSC genome browser from here!"),
                              shiny::tags$p(" "),
                              shiny::tags$p("Number displayed on structural variants is the allele frequency"),
                              shiny::tags$p("Click plot to visualize changes after updating genomic coordinates, using zoom, gene search or changing phenotype"),
                              shiny::tags$br(style="line-height: 10px"),
                              radioButtons(inputId = "pheno", label = "Phenotype", choiceValues = c("LBD", "FTD"), choiceNames = c("LBD", "FTD/ALS"), inline = TRUE),
                              shiny::tags$p("Gene search", style = "font-size:14px;"),
                              shiny::tags$p(" "),
                              textInput.typeahead(id="gene_search", placeholder = "Gene name, e.g. GBA", local=data.frame(name=c(gene_info$external_gene_name)), valueKey = "name", tokens =  c(1:length(gene_info$external_gene_name)), template = HTML("<p style='font-size:12px;'class='repo-name'>{{name}}</p>")),
                              pickerInput(inputId = "chrom", label = "Chromosome", choices = c("chr1","chr2","chr3","chr4","chr5","chr6","chr7","chr8","chr9","chr10","chr11","chr12","chr13","chr14","chr15","chr16","chr17","chr18","chr19","chr20","chr21","chr22","chrX"), multiple = FALSE),
                              numericRangeInput(inputId = "genomic_range", label = "Genomic range in bp (hg38)", value = c(155234452,155244699)),
                              shiny::actionButton(inputId = "zoom_out_3", label = "Zoom out x3"),
                              shiny::actionButton(inputId = "zoom_in_3", label = "Zoom in x3"),
                              shiny::tags$br(),
                              shiny::tags$p(" "),
                              shiny::actionButton(inputId = "plot", label = "Plot", icon = icon(name = "play", lib = "font-awesome"), style='font-size:20px'),
                              shiny::tags$br(),
                              imageOutput(outputId = "color_legend2", width = "100%")
                            ),
                            mainPanel(
                              imageOutput(outputId = "img3")
                            )
                          )
                          
                 ),
                 tabPanel("Genome-wide data frame", icon = icon(name = "table-list", lib = "font-awesome"),
                          sidebarLayout(
                            sidebarPanel(
                              width = 3,
                              shiny::tags$a(href="https://github.com/ruthchia/Structural_variant_analysis-LBD-FTD/tree/main/Structural_variant_files", 
                                     "Download the data frames from here"),
                              radioButtons(inputId = "pheno_gw", label = "Phenotype", choiceValues =  c("LBD_gw", "FTD_gw"), choiceNames = c("LBD", "FTD/ALS")),
                              filter_data_ui("filtering_gw")
                            ),
                            mainPanel(
                              DT::dataTableOutput(outputId = "table_gw"),
                            )
                          )
                 ),
                 tabPanel("Info", icon = icon("info"),
                        mainPanel(
                          shiny::tags$h1("Structural variants in non-Alzheimer's dementias app"),
                          shiny::tags$h2("Background"),
                          shiny::tags$p("Structural variants cause most variation in genomes but they have been rarely studied due to technical difficulties. This app presents data from Lewy body dementia (LBD) and frontotemporal dementia-amyotrophic lateral sclerosis (FTD/ALS) patients and neurologically healthy controls."),
                          shiny::tags$p("For more details please see our manuscript."),
                          shiny::tags$h2("Structural variant calling and filtering"),
                          shiny::tags$p("Structural variant calling was performed with GATK-SV, which uses five structural variant detection algorithms and machine learning to produce consensus variant calls and genotype filtering. The data presented in this app is a high-quality subset of structural variants that was created by further filtering the GATK-SV output with the following criteria:"),
                          shiny::tags$p("1. 1 % FDR"),
                          shiny::tags$p("2. Variant filter type PASS, MULTIALLELIC, UNRESOLVED"),
                          shiny::tags$p("3. GQ < 300 set to missing"),
                          shiny::tags$p("4. Genotyping rate > 95 %"),
                          shiny::tags$p("5. HWE mid-p adjusted p-value > 0.000001"),
                          shiny::tags$p("The final LBD dataset consisted of 2,355 LBD vs. 3,700 controls with 150,752 structural variants"),
                          shiny::tags$p("The final FTD/ALS dataset consisted of 2,307 LBD vs. 3,677 controls with 158,991 structural variants"),
                          shiny::tags$h2("Contact information"),
                          shiny::tags$h4("Karri Kaivola (Application questions)"),
                          shiny::tags$p("karri.kaivola@nih.gov / karri.kaivola@helsinki.fi"),
                          shiny::tags$p("Neurodegenerative Diseases Research Unit"),
                          shiny::tags$p("National Institute of Neurological Disorders and Stroke"),
                          shiny::tags$p("National Institutes of Health"),
                          shiny::tags$p("Bethesda, Maryland 20892"),
                          shiny::tags$p("United States"),
                          shiny::tags$h4("Sonja W. Scholz (PI, LBD)"),
                          shiny::tags$p("sonja.scholz@nih.gov"),
                          shiny::tags$p("Neurodegenerative Diseases Research Unit"),
                          shiny::tags$p("National Institute of Neurological Disorders and Stroke"),
                          shiny::tags$p("National Institutes of Health"),
                          shiny::tags$p("Bethesda, Maryland 20892"),
                          shiny::tags$p("United States"),
                          shiny::tags$h4("Bryan J. Traynor (PI, FTD/ALS)"),
                          shiny::tags$p("bryan.traynor@nih.gov"),
                          shiny::tags$p("Neuromuscular Diseases Research Section"),
                          shiny::tags$p("Laboratory of Neurogenetics"),
                          shiny::tags$p("National Institute on Aging"),
                          shiny::tags$p("National Institutes of Health"),
                          shiny::tags$p("Bethesda, Maryland 20892"),
                          shiny::tags$p("United States")
                        )  
                          )
)


#Define server
server <- function(input, output, session) {
  
  ##Test
  data_gw <- reactive({
    get(input$pheno_gw)
  })
  
  vars_gw <- reactive({
    if (identical(input$pheno_gw, "LBD_gw")) {
      colnames(LBD_gw)[2:12]
    } else {
      colnames(FTD_gw)[2:12]
    }
  })
  
  res_filter_gw <- filter_data_server(
    id = "filtering_gw",
    data = data_gw,
    name = reactive(input$pheno_gw),
    widget_num = "range",
    widget_date = "slider",
    widget_char = "picker",
    label_na = "Missing",
    drop_ids = FALSE,
    vars = vars_gw
  )
  
  output$table_gw <- DT::renderDT({
    res_filter_gw$filtered()
  }, options = list(pageLength = 50))

  ##Outputs of SV color legends for SV plots    
  output$color_legend <- renderImage({
    list(src=file.path("color_code_legend.png"))
  }, deleteFile = FALSE)
  
  output$color_legend2 <- renderImage({
    list(src=file.path("color_code_legend.png"))
  }, deleteFile = FALSE)
  
  ##Output NDD gene pre-rendered plots
  output$img2 <- renderImage({
    list(
      src = file.path("NIH_SV_images/",input$pheno2,paste0(input$gene2,"_",input$pheno2,"_candidate_gene_overlap.png")))
  }, deleteFile=FALSE)
  
  ##Output info text
  output$SV_info2 <- renderText({
    "Allele frequency presented on structural variants \n"
  })
  
  ##NDD gene data frame filtering and output
  data <- reactive({
    get(input$dataset)
  })
  
  
  vars <- reactive({
    if (identical(input$dataset, "LBD")) {
      colnames(LBD)[c(1:3,6:22)]
    } else {
      colnames(FTD)[c(1:3,6:22)]
    }
  })
  
  res_filter <- filter_data_server(
    id = "filtering",
    data = data,
    name = reactive(input$dataset),
    widget_num = "range",
    widget_date = "slider",
    widget_char = "picker",
    label_na = "Missing",
    drop_ids = FALSE,
    vars = vars
  )
  
  output$table <- DT::renderDT({
    res_filter$filtered()
  }, options = list(pageLength = 50))
  
  ##Genome-wide plotting
  ###Input from gene search box updates chromosome and genomic coordinates
  observe({
    gene_name <- input$gene_search
    updatePickerInput(
      session = session,
      inputId = "chrom",
      selected = gene_info$chromosome_name[gene_info$external_gene_name == gene_name]
    )
    updateNumericRangeInput(
      session = session,
      inputId = "genomic_range",
      value = c(gene_info$start_position[gene_info$external_gene_name == gene_name], gene_info$end_position[gene_info$external_gene_name == gene_name]),
    )
  }) %>% bindEvent(input$gene_search, ignoreInit = TRUE)
  
  ###Input from zoom buttons updates genomic coordinates
  observe({
    updateNumericRangeInput(
      session = session,
      inputId = "genomic_range",
      value = c(round(input$genomic_range[1]-((input$genomic_range[2]-input$genomic_range[1])*1.5)), round(input$genomic_range[2]+((input$genomic_range[2]-input$genomic_range[1])*1.5)))
    )
  }) %>% bindEvent(input$zoom_out_3, ignoreInit = TRUE)
  
  observe({
    updateNumericRangeInput(
      session = session,
      inputId = "genomic_range",
      value = c(round(input$genomic_range[1]+((input$genomic_range[2]-input$genomic_range[1])/1.5)), round(input$genomic_range[2]-((input$genomic_range[2]-input$genomic_range[1])/1.5)))
    )
  }) %>% bindEvent(input$zoom_in_3, ignoreInit = TRUE)
  
  ###Plot user-defined genomic region
  output$img3 <- renderPlot(width = "auto", height = "auto", {
    #Set variables based on genomic range input
    chr <- input$chrom
    start <- input$genomic_range[1]
    stop <- input$genomic_range[2]
    #Select df to plot
    if(input$pheno == "LBD") {
      df_cases <- LBD_cases
      df_controls <- LBD_controls
    } else {
      df_cases <- FTD_cases
      df_controls <- FTD_controls
    }
    ##Find overlaps (3 different criteria) with input region and dfs and extract IDs for filtering
    tmp_cases1 <- df_cases %>%
      filter(CHROM == chr) %>%
      filter(END >= start & END <= stop)
    tmp_cases2 <- df_cases %>%
      filter(CHROM == chr) %>%
      filter(POS >= start & POS <= stop)
    tmp_cases3 <- df_cases %>%
      filter(CHROM == chr) %>%
      filter(POS <= start & END >=stop)
    tmp_IDs_cases <- unique(c(tmp_cases1$ID, tmp_cases2$ID, tmp_cases3$ID))
    tmp_cases <- df_cases %>%
      filter(ID %in% tmp_IDs_cases)
    
    tmp_controls1 <- df_controls %>%
      filter(CHROM == chr) %>%
      filter(END >= start & END <= stop)
    tmp_controls2 <- df_controls %>%
      filter(CHROM == chr) %>%
      filter(POS >= start & POS <= stop)
    tmp_controls3 <- df_controls %>%
      filter(CHROM == chr) %>%
      filter(POS <= start & END >=stop)
    tmp_IDs_controls <- unique(c(tmp_controls1$ID, tmp_controls2$ID, tmp_controls3$ID))
    tmp_controls <- df_controls %>%
      filter(ID %in% tmp_IDs_controls)
    
    ##So that text is shown in plot: if SV POS < start, make POS = start.
    tmp_cases$POS[tmp_cases$POS < start] <- start
    tmp_controls$POS[tmp_controls$POS < start] <- start
    ##So that text is shown in plot: if SV END > stop, make END = stop.
    tmp_cases$END[tmp_cases$END >  stop] <- stop
    tmp_controls$END[tmp_controls$END > stop] <- stop
    ##Make tracks and plot
    if ((nrow(tmp_cases) > 0) & (nrow(tmp_controls) > 0)) {
      gtrack <- GenomeAxisTrack(fontsize=12)
      itrack <- IdeogramTrack(genome = "hg38", chromosome = chr, fontsize=14)
      biomTrack <- BiomartGeneRegionTrack(transcriptAnnotation = "symbol", genome = "hg38",chromosome = chr, start = start, end = stop, name = "Gene", filter = list(transcript_is_canonical = TRUE), biomart = bm, just.group="below", protein_coding="gray", utr3="gray", utr5="gray", fill="gray")
      atrack_cases <- AnnotationTrack(start=tmp_cases$POS, end=tmp_cases$END, chromosome = chr, genome="hg38", name="Cases", feature = tmp_cases$SVTYPE, id=tmp_cases$AF_cases, showFeatureId = TRUE, fontcolor.item="black", col.line="white", min.width=2)
      atrack_controls <- AnnotationTrack(start=tmp_controls$POS, end=tmp_controls$END, chromosome = chr, genome="hg38", name="Controls", feature = tmp_controls$SVTYPE, id=tmp_controls$AF_controls, showFeatureId = TRUE, fontcolor.item="black", min.width=2)
      plotTracks(list(itrack,gtrack, atrack_cases, atrack_controls, biomTrack), from = start, to = stop, fontcolor.title="#808080", fontsize.group=20, fontsize.title=20, BND="#377246", CPX="#86E496", DEL="#D6402D", DUP="#5282AF", INS="#D579E1", INS_ME="#F6AAFF", INS_ME_ALU="#F6AAFF", INS_ME_LINE1="#F6AAFF", INS_ME_SVA="#F6AAFF", INV="#F69A57")
    } else if ((nrow(tmp_cases) > 0) & (nrow(tmp_controls) == 0)) {
      gtrack <- GenomeAxisTrack(fontsize=12)
      itrack <- IdeogramTrack(genome = "hg38", chromosome = chr, fontsize=14)
      biomTrack <- BiomartGeneRegionTrack(transcriptAnnotation = "symbol", genome = "hg38",chromosome = chr, start = start, end = stop, name = "Gene", filter = list(transcript_is_canonical = TRUE), biomart = bm, just.group="below", protein_coding="gray", utr3="gray", utr5="gray", fill="gray")
      atrack_cases <- AnnotationTrack(start=tmp_cases$POS, end=tmp_cases$END, chromosome = chr, genome="hg38", name="Cases", feature = tmp_cases$SVTYPE, id=tmp_cases$AF_cases, showFeatureId = TRUE, fontcolor.item="black", min.width=2)
      plotTracks(list(itrack,gtrack, atrack_cases, biomTrack), from = start, to = stop, fontcolor.title="#808080", fontsize.group=20, fontsize.title=20, BND="#377246", CPX="#86E496", DEL="#D6402D", DUP="#5282AF", INS="#D579E1", INS_ME="#F6AAFF", INS_ME_ALU="#F6AAFF", INS_ME_LINE1="#F6AAFF", INS_ME_SVA="#F6AAFF", INV="#F69A57")
    } else if ((nrow(tmp_cases) == 0) & (nrow(tmp_controls) == 0)) {
      gtrack <- GenomeAxisTrack(showTitle=TRUE, name="No SVs", fontcolor.title="#808080", rotation.title=0)
      plotTracks(gtrack, from = 100, to = 110, title.width = 5)
    } else {
      gtrack <- GenomeAxisTrack(fontsize=12)
      itrack <- IdeogramTrack(genome = "hg38", chromosome = chr, fontsize=14)
      biomTrack <- BiomartGeneRegionTrack(transcriptAnnotation = "symbol", genome = "hg38",chromosome = chr, start = start, end = stop, name = "Gene", filter = list(transcript_is_canonical = TRUE), biomart = bm, just.group="below", protein_coding="gray", utr3="gray", utr5="gray", fill="gray")
      atrack_controls <- AnnotationTrack(start=tmp_controls$POS, end=tmp_controls$END, chromosome = chr, genome="hg38", name="Controls", feature = tmp_controls$SVTYPE, id=tmp_controls$AF_controls, showFeatureId = TRUE, fontcolor.item="black", min.width=2)
      plotTracks(list(itrack,gtrack, atrack_controls, biomTrack), from = start, to = stop, fontcolor.title="#808080", fontsize.group=20, fontsize.title=20, BND="#377246", CPX="#86E496", DEL="#D6402D", DUP="#5282AF", INS="#D579E1", INS_ME="#F6AAFF", INS_ME_ALU="#F6AAFF", INS_ME_LINE1="#F6AAFF", INS_ME_SVA="#F6AAFF", INV="#F69A57")
    }
  }) %>% bindEvent(input$plot, ignoreInit = FALSE, ignoreNULL = FALSE)
}

#Launch shiny app
shinyApp(ui, server)

